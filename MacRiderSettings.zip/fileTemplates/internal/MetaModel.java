/*
 * Created by Rider.
 * User: ${USER}
 * Date: ${DATE}
 * Time: ${TIME}
 */
package ${PACKAGE_NAME};
public metamodel ${NAME} { }